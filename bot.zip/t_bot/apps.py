from django.apps import AppConfig


class TBotConfig(AppConfig):
    name = 't_bot'
